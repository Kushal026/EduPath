import React, { useState } from 'react';
import { ArrowRight, BookOpen, Briefcase, GraduationCap } from 'lucide-react';

interface CareerPath {
  stream: string;
  degrees: string[];
  careers: string[];
  exams: string[];
  color: string;
}

const careerPaths: CareerPath[] = [
  {
    stream: 'Science',
    degrees: ['B.Tech/B.E.', 'MBBS', 'B.Sc. Physics', 'B.Sc. Chemistry', 'B.Sc. Mathematics', 'B.Sc. Biology', 'B.Pharma', 'B.Arch', 'B.Sc. Agriculture', 'B.Sc. Nursing'],
    careers: ['Software Engineer', 'Doctor', 'Research Scientist', 'Data Scientist', 'Pharmacist', 'Architect', 'Agricultural Scientist', 'Biotechnologist', 'Environmental Scientist', 'Aerospace Engineer'],
    exams: ['JEE Main/Advanced', 'NEET', 'GATE', 'CSIR-NET', 'IIT JAM', 'NATA', 'ICAR AIEEA'],
    color: 'blue'
  },
  {
    stream: 'Commerce',
    degrees: ['B.Com', 'BBA', 'B.Com (H)', 'BCA', 'B.Sc. Economics', 'BMS', 'B.Com Banking', 'B.Com Taxation', 'B.Com International Business'],
    careers: ['Chartered Accountant', 'Business Analyst', 'Financial Advisor', 'Bank Manager', 'Investment Banker', 'Tax Consultant', 'Company Secretary', 'Financial Planner', 'Entrepreneur', 'Digital Marketing Manager'],
    exams: ['CA Foundation', 'CS Executive', 'CMA', 'CLAT', 'MAT', 'CAT', 'XAT', 'SNAP'],
    color: 'green'
  },
  {
    stream: 'Arts',
    degrees: ['B.A. English', 'B.A. History', 'B.A. Political Science', 'B.A. Psychology', 'B.A. Sociology', 'B.A. Economics', 'B.A. Philosophy', 'B.A. Geography', 'B.A. Fine Arts', 'B.A. Mass Communication'],
    careers: ['Journalist', 'Teacher', 'Civil Servant', 'Social Worker', 'Content Writer', 'Counselor', 'Diplomat', 'Historian', 'Psychologist', 'Artist', 'Film Director', 'Public Relations Officer'],
    exams: ['UPSC', 'SSC', 'UGC-NET', 'State PSC', 'CLAT', 'JMI Mass Comm', 'IIMC Entrance'],
    color: 'purple'
  },
  {
    stream: 'Vocational',
    degrees: ['Diploma in Engineering', 'ITI Courses', 'Hotel Management', 'Fashion Design', 'Interior Design', 'Animation', 'Photography', 'Culinary Arts', 'Beauty & Wellness'],
    careers: ['Technical Specialist', 'Hotel Manager', 'Fashion Designer', 'Interior Designer', 'Animator', 'Chef', 'Beauty Therapist', 'Photographer', 'Event Manager', 'Travel Guide'],
    exams: ['Polytechnic Entrance', 'NIFT', 'NID', 'NCHM JEE', 'UCEED'],
    color: 'orange'
  },
  {
    stream: 'Professional',
    degrees: ['LLB', 'B.Ed', 'B.Arch', 'B.Des', 'BFA', 'B.Journalism', 'B.Lib.Sc', 'B.P.Ed'],
    careers: ['Lawyer', 'Teacher', 'Architect', 'Designer', 'Artist', 'Journalist', 'Librarian', 'Sports Coach', 'Judge', 'Legal Advisor'],
    exams: ['CLAT', 'AILET', 'B.Ed Entrance', 'NATA', 'UCEED', 'JMI Mass Comm', 'IGNOU B.Ed'],
    color: 'red'
  },
  {
    stream: 'Technology',
    degrees: ['BCA', 'B.Tech IT', 'B.Sc. Computer Science', 'B.Sc. IT', 'Diploma in Computer Applications', 'B.Voc Software Development'],
    careers: ['Software Developer', 'Web Developer', 'Mobile App Developer', 'System Administrator', 'Database Administrator', 'Cybersecurity Specialist', 'AI/ML Engineer', 'Game Developer'],
    exams: ['JEE Main', 'State CET', 'NIMCET', 'BCA Entrance'],
    color: 'indigo'
  }
];

export const CareerPaths: React.FC = () => {
  const [selectedStream, setSelectedStream] = useState<string | null>(null);

  const getColorClasses = (color: string, variant: 'bg' | 'text' | 'border') => {
    const colorMap = {
      blue: { bg: 'bg-blue-600', text: 'text-blue-600', border: 'border-blue-600' },
      green: { bg: 'bg-green-600', text: 'text-green-600', border: 'border-green-600' },
      purple: { bg: 'bg-purple-600', text: 'text-purple-600', border: 'border-purple-600' },
      orange: { bg: 'bg-orange-600', text: 'text-orange-600', border: 'border-orange-600' },
      red: { bg: 'bg-red-600', text: 'text-red-600', border: 'border-red-600' },
      indigo: { bg: 'bg-indigo-600', text: 'text-indigo-600', border: 'border-indigo-600' }
    };
    return colorMap[color as keyof typeof colorMap][variant];
  };

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Explore Career Pathways</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Discover the journey from choosing your stream to building a successful career.
            Each path offers unique opportunities and growth potential.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {careerPaths.map((path, index) => (
            <div
              key={index}
              className={`bg-white rounded-xl shadow-lg border-2 transition-all cursor-pointer ${
                selectedStream === path.stream
                  ? `${getColorClasses(path.color, 'border')} shadow-xl transform scale-105`
                  : 'border-gray-200 hover:shadow-xl'
              }`}
              onClick={() => setSelectedStream(selectedStream === path.stream ? null : path.stream)}
            >
              <div className={`${getColorClasses(path.color, 'bg')} p-6 rounded-t-xl`}>
                <h3 className="text-xl font-bold text-white">{path.stream} Stream</h3>
                <p className="text-white/90 mt-2">Click to explore career pathways</p>
              </div>

              <div className="p-6">
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center space-x-2 mb-3">
                      <GraduationCap className={`w-5 h-5 ${getColorClasses(path.color, 'text')}`} />
                      <h4 className="font-semibold text-gray-900">Degree Options</h4>
                    </div>
                    <div className="space-y-2">
                      {path.degrees.slice(0, selectedStream === path.stream ? path.degrees.length : 3).map((degree, idx) => (
                        <span
                          key={idx}
                          className="inline-block bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm mr-2 mb-2"
                        >
                          {degree}
                        </span>
                      ))}
                    </div>
                  </div>

                  {selectedStream === path.stream && (
                    <>
                      <div>
                        <div className="flex items-center space-x-2 mb-3">
                          <Briefcase className={`w-5 h-5 ${getColorClasses(path.color, 'text')}`} />
                          <h4 className="font-semibold text-gray-900">Career Opportunities</h4>
                        </div>
                        <div className="space-y-2">
                          {path.careers.map((career, idx) => (
                            <div key={idx} className="flex items-center space-x-2">
                              <ArrowRight className="w-4 h-4 text-gray-400" />
                              <span className="text-gray-600">{career}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center space-x-2 mb-3">
                          <BookOpen className={`w-5 h-5 ${getColorClasses(path.color, 'text')}`} />
                          <h4 className="font-semibold text-gray-900">Competitive Exams</h4>
                        </div>
                        <div className="space-y-2">
                          {path.exams.map((exam, idx) => (
                            <span
                              key={idx}
                              className={`inline-block border ${getColorClasses(path.color, 'border')} ${getColorClasses(path.color, 'text')} px-3 py-1 rounded-full text-sm mr-2 mb-2`}
                            >
                              {exam}
                            </span>
                          ))}
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <div className="bg-blue-50 rounded-xl p-8 max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Need Personalized Guidance?</h3>
            <p className="text-gray-600 mb-6">
              Take our aptitude quiz to get customized recommendations based on your interests and strengths.
            </p>
            <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center space-x-2">
              <span>Take Aptitude Quiz</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};